package com.netcracker.edu.api.manager;

import com.netcracker.edu.api.model.Place;
import com.netcracker.edu.api.model.Rating;
import com.netcracker.edu.api.service.PlaceService;
import com.netcracker.edu.api.service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

@Service
public class RatingManager {

    @Autowired
    private RatingService ratingService;

    @Autowired
    private PlaceService placeService;

    public String ratingToString() {
        List<Rating> ratings = ratingService.sortTenList();
        int[] placeIds = new int[ratings.size()];
        for (int i = 0; i < ratings.size(); i++) {
            placeIds[i] = ratings.get(i).getId();
        }
        List<Place> places = placeService.findPlaceById(placeIds);
        message;
        for (int i = 0; i < ratings.size(); i++){
            message =
        }
    }

    public List<Rating> findPopularPlace(int[] placeId) {
        return ratingService.findPopularPlace(placeId);
    }
}
