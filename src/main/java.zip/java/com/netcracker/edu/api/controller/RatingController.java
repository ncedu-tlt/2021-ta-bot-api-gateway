package com.netcracker.edu.api.controller;

import com.netcracker.edu.api.manager.RatingManager;
import com.netcracker.edu.api.model.Rating;
import com.netcracker.edu.api.service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/")
public class RatingController {

    @Autowired
    private RatingManager ratingManager;


    @GetMapping("/rating/tenbestplace/")
    public ResponseEntity <List<Rating>> findTopPlace() {
        return ResponseEntity.ok(ratingManager.sortTenList());
    }


    @PostMapping("/rating/topplaces/")
    public ResponseEntity <List<Rating>> findPopularPlace(@RequestBody int placeId[]) {
        return ResponseEntity.ok(ratingManager.findPopularPlace(placeId));
    }


}
