package com.netcracker.edu.api.model.ui;

import lombok.Data;

@Data
public class UiPlace {

    private String city;
    private String address;
    private String categoryName;

}
