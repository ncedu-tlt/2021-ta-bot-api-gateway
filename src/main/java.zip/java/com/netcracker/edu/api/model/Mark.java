package com.netcracker.edu.api.model;

import lombok.Data;

@Data
public class Mark {

    private int id;
    private String value;

    public Mark() {
    }


}
