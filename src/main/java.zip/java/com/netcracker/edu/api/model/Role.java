package com.netcracker.edu.api.model;

import lombok.Data;

@Data
public class Role {

    private int id;
    private String role;

}
